# Resources

In this directory you can push all kinds of resources.
For example:
- PDFs of literature you want to share with your advisor
- Source code, in case some implementations are part of the seminar
- ...
