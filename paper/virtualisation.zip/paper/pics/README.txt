Put all external images here that are not built.
For example: *.jpg, *.png, *.pdf
