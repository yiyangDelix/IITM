#!/bin/bash

iserror=0
allowed=("topic-preferences.txt" "paper/" "talk/" "feedback/" "review1/" "review2/" "resources/")
allowed_review=("paper.pdf" "review.txt" "paper-annotated.pdf")

RED='\033[01;31m'
GREEN='\033[01;32m'
RESTORE='\033[0m'

print_error () {
	echo -e "${RED}The file $1 is not allowed at the current location${RESTORE}"
}

check_directory () {
	local directory="$1"   # Save first argument in a variable
    shift            # Shift all arguments to the left (original $1 gets lost)
    local whitelist=("$@") # Rebuild the array with rest of arguments

	tree -L 1 $directory
	for f in $(ls -1p ${directory}); do
		matched=0
		for a in "${whitelist[@]}"; do
			if [[ $f == $a  ]]; then
				matched=1
				break
			fi
		done;
		if [[ $matched == 0 ]]; then
			print_error $f
			let iserror+=1
		fi
	done;
}

check_directory . "${allowed[@]}"

for review in $(ls -1p | grep review); do
	check_directory $review "${allowed_review[@]}"
done;

if [[ $iserror -gt 0 ]]; then
	echo
	echo -e "${RED}Please fix the ${iserror} issue(s) with the directory structure${RESTORE}"
	exit 1
fi

echo -e "${GREEN}Directory structure verified${RESTORE}"
exit 0

