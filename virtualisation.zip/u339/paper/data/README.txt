Put all additional data here which you use for plots or tabels in the
paper.
For example: *.csv
