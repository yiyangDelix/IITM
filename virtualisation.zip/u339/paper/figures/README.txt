Put all external latex figures here. They are automatically built with
the Makefile.
For example: *.tex, *.tikz
